import { useState } from "react";

const API = "http://localhost:8080/api";

const inputStyle = {
  width: "100%", padding: "12px 16px",
  background: "#0a0a0a", border: "1px solid #2a2a2a",
  borderRadius: "3px", color: "#f0f0f0",
  fontFamily: "Inter, sans-serif", fontSize: "14px",
  outline: "none", transition: "border-color 0.2s"
};

const labelStyle = {
  display: "block", fontFamily: "Oswald, sans-serif",
  fontSize: "11px", letterSpacing: "2px", color: "#666",
  marginBottom: "6px"
};

export default function Registration({ showNotification, setActivePage }) {
  const [form, setForm] = useState({
    name: "", email: "", phone: "", age: "",
    plan: "BASIC", emergencyContact: "", address: ""
  });
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});

  const plans = [
    { id: "BASIC", label: "Basic", price: "₹999/mo", features: "Access to gym floor" },
    { id: "PREMIUM", label: "Premium", price: "₹1,799/mo", features: "Gym + Classes + Locker" },
    { id: "ANNUAL", label: "Annual", price: "₹8,999/yr", features: "All Premium + Personal trainer" },
  ];

  const validate = () => {
    const e = {};
    if (!form.name.trim()) e.name = "Name is required";
    if (!form.email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) e.email = "Valid email required";
    if (!form.phone.match(/^\d{10}$/)) e.phone = "10-digit phone number required";
    if (!form.age || form.age < 16 || form.age > 80) e.age = "Age must be between 16–80";
    return e;
  };

  const handleSubmit = async () => {
    const e = validate();
    if (Object.keys(e).length > 0) { setErrors(e); return; }
    setLoading(true);
    try {
      const res = await fetch(`${API}/members`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, age: parseInt(form.age), status: "ACTIVE",
          membershipFee: form.plan === "BASIC" ? 999 : form.plan === "PREMIUM" ? 1799 : 8999 })
      });
      if (res.ok) {
        showNotification(`✅ ${form.name} registered successfully!`);
        setForm({ name: "", email: "", phone: "", age: "", plan: "BASIC", emergencyContact: "", address: "" });
        setErrors({});
        setTimeout(() => setActivePage("members"), 1500);
      } else throw new Error();
    } catch {
      showNotification("⚠️ Backend not connected. In real app, member would be saved!", "error");
    }
    setLoading(false);
  };

  const Field = ({ label, field, type = "text", placeholder }) => (
    <div style={{ marginBottom: "20px" }}>
      <label style={labelStyle}>{label}</label>
      <input
        type={type} placeholder={placeholder} value={form[field]}
        onChange={e => { setForm({ ...form, [field]: e.target.value }); setErrors({ ...errors, [field]: null }); }}
        style={{ ...inputStyle, borderColor: errors[field] ? "#ff3a20" : "#2a2a2a" }}
        onFocus={e => e.target.style.borderColor = errors[field] ? "#ff3a20" : "#ff3a2066"}
        onBlur={e => e.target.style.borderColor = errors[field] ? "#ff3a20" : "#2a2a2a"}
      />
      {errors[field] && <div style={{ color: "#ff3a20", fontSize: "11px", fontFamily: "Inter", marginTop: "4px" }}>{errors[field]}</div>}
    </div>
  );

  return (
    <div>
      <div style={{ marginBottom: "40px" }}>
        <div style={{ fontSize: "48px", letterSpacing: "6px", lineHeight: 1 }}>NEW MEMBER</div>
        <div style={{ color: "#555", fontFamily: "Inter", fontSize: "13px", marginTop: "6px", letterSpacing: "2px" }}>MEMBERSHIP REGISTRATION</div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 380px", gap: "32px" }}>
        {/* Form */}
        <div style={{ background: "#111", border: "1px solid #1e1e1e", borderRadius: "4px", padding: "32px" }}>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0 24px" }}>
            <Field label="FULL NAME *" field="name" placeholder="John Doe" />
            <Field label="AGE *" field="age" type="number" placeholder="25" />
            <Field label="EMAIL ADDRESS *" field="email" type="email" placeholder="john@email.com" />
            <Field label="PHONE NUMBER *" field="phone" placeholder="9876543210" />
            <div style={{ gridColumn: "1/-1", marginBottom: "20px" }}>
              <Field label="ADDRESS" field="address" placeholder="123 Main St, City" />
            </div>
            <Field label="EMERGENCY CONTACT" field="emergencyContact" placeholder="9876543211" />
          </div>

          {/* Plan Selection */}
          <div style={{ marginBottom: "28px" }}>
            <label style={labelStyle}>MEMBERSHIP PLAN *</label>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "12px" }}>
              {plans.map(plan => (
                <div key={plan.id} onClick={() => setForm({ ...form, plan: plan.id })} style={{
                  padding: "16px", border: `1px solid ${form.plan === plan.id ? "#ff3a20" : "#2a2a2a"}`,
                  borderRadius: "3px", cursor: "pointer",
                  background: form.plan === plan.id ? "#ff3a2010" : "#0a0a0a",
                  transition: "all 0.2s"
                }}>
                  <div style={{ fontFamily: "Oswald", letterSpacing: "2px", fontSize: "14px", color: form.plan === plan.id ? "#ff3a20" : "#aaa" }}>{plan.label}</div>
                  <div style={{ fontFamily: "Inter", fontSize: "16px", fontWeight: "600", margin: "4px 0", color: "#f0f0f0" }}>{plan.price}</div>
                  <div style={{ fontFamily: "Inter", fontSize: "10px", color: "#555" }}>{plan.features}</div>
                </div>
              ))}
            </div>
          </div>

          <button onClick={handleSubmit} disabled={loading} style={{
            width: "100%", padding: "16px",
            background: loading ? "#333" : "linear-gradient(135deg, #ff3a20, #cc2a10)",
            border: "none", borderRadius: "3px", cursor: loading ? "not-allowed" : "pointer",
            color: "#fff", fontFamily: "Oswald, sans-serif",
            fontSize: "16px", letterSpacing: "4px",
            transition: "all 0.2s"
          }}>
            {loading ? "REGISTERING..." : "REGISTER MEMBER →"}
          </button>
        </div>

        {/* Preview Card */}
        <div>
          <div style={{ background: "linear-gradient(135deg, #1a0a0a, #0a0a1a)", border: "1px solid #ff3a2033", borderRadius: "8px", padding: "28px", position: "sticky", top: "40px" }}>
            <div style={{ fontSize: "10px", letterSpacing: "4px", color: "#ff3a20", marginBottom: "20px", fontFamily: "Oswald" }}>MEMBER CARD PREVIEW</div>
            <div style={{ fontSize: "24px", letterSpacing: "2px", marginBottom: "4px" }}>{form.name || "MEMBER NAME"}</div>
            <div style={{ fontFamily: "Inter", fontSize: "12px", color: "#555", marginBottom: "20px" }}>{form.email || "email@example.com"}</div>
            <div style={{ borderTop: "1px solid #ff3a2022", paddingTop: "16px" }}>
              {[
                { label: "PLAN", value: form.plan },
                { label: "PHONE", value: form.phone || "—" },
                { label: "AGE", value: form.age || "—" },
                { label: "STATUS", value: "ACTIVE" },
              ].map((item, i) => (
                <div key={i} style={{ display: "flex", justifyContent: "space-between", marginBottom: "10px", fontFamily: "Inter", fontSize: "12px" }}>
                  <span style={{ color: "#444", letterSpacing: "2px", fontFamily: "Oswald" }}>{item.label}</span>
                  <span style={{ color: item.label === "STATUS" ? "#4caf50" : "#aaa" }}>{item.value}</span>
                </div>
              ))}
            </div>
            <div style={{ marginTop: "20px", padding: "12px", background: "#ff3a2010", border: "1px solid #ff3a2033", borderRadius: "3px", fontFamily: "Inter", fontSize: "11px", color: "#ff7a60", textAlign: "center" }}>
              🏋️ IRON GYM MEMBERSHIP
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
